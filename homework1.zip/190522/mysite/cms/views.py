from django.shortcuts import render_to_response
# Create your views here.
from .models import About

def index(request):
	abouts = About.objects.all()
	return render_to_response('cms/menu.html',locals())